# 介质访问控制

> 《计算机网络》· 数据链路层

### 多路复用(重要度:★★★★★)

#### 多路复用

**多路复用**让多路信号共享同一条物理链路，在逻辑上看起来各自独占信道。做法是把链路资源（时间、频率、波长等）分割成互不重叠的子信道，分配给不同用户。

#### 频分复用 FDM

**频分复用**将信道总带宽划分为多个互不重叠的子频段，每个子频段分配给一路信号。各路信号**同时传输**，但在**频域上分开**。接收方用带通滤波器分离各路信号。

![示意图](../../assets/computer-network/kb-multiplexing-fdm-3.svg)

各路信号的载波频率不同，被调制到不同的频段上。相邻频段之间需留保护频带防止串扰。典型应用：广播电台（各台占用不同频率）、有线电视、ADSL。

#### 时分复用 TDM

**时分复用**将时间划分为固定长度的帧，每帧再划分为固定数量的时隙，每个时隙分配给一路信号。各路信号轮流使用信道，在时域上分开，每个用户在自己的时隙内独占整个带宽。

![示意图](../../assets/computer-network/kb-multiplexing-tdm-3.svg)

**同步 TDM**：每个时隙固定分配，即使某路无数据也占着时隙不放。

**统计 TDM**：按需分配时隙，有数据的终端才占用，无数据的跳过。利用率高于同步 TDM，但需要额外地址信息标识数据来源。

#### 波分复用 WDM

**波分复用**是频分复用在光纤上的变体：将不同波长的光信号合并到同一根光纤中传输，接收端用光滤波器分离。光的波长与频率一一对应（$c = \lambda f$），波长不同即频率不同。

![示意图](../../assets/computer-network/kb-multiplexing-wdm-2.svg)

#### 码分复用 CDM

**码分复用**给每个用户分配唯一的正交码片序列。发送时用码片序列与数据相乘，接收方用相同的码片序列做内积恢复数据。不同用户的信号在时间和频率上都重叠，靠正交码分离。**CDMA**（码分多址）移动通信广泛使用此技术。

**例** 用户 A 码片 $(+1,+1,+1,+1)$，用户 B 码片 $(+1,-1,+1,-1)$。两用户各发送 bit 1，叠加后接收方如何分离？

**第 1 步：编码**，发送方用数据 bit × 码片序列。发送 bit 1 则码片原样发出，发送 bit 0 则码片反相（全部取反）。A 发 bit 1 → $(+1,+1,+1,+1)$，B 发 bit 1 → $(+1,-1,+1,-1)$。

**第 2 步：叠加**，信道中两路信号线性叠加（对应位置相加）：$(+2, 0, +2, 0)$。

**第 3 步：解码**，接收方用目标用户的码片与叠加信号做内积，再除以码片长度。
A 解码：$[(+2)(+1) + (0)(+1) + (+2)(+1) + (0)(+1)] / 4 = 4/4 = +1$ → bit 1。
B 解码：$[(+2)(+1) + (0)(-1) + (+2)(+1) + (0)(-1)] / 4 = 4/4 = +1$ → bit 1。

> 💡 **正交码片的内积为零**
>
> 不同用户的码片两两正交，内积为 0。如 A 与 B 的码片内积：$(+1)(+1) + (+1)(-1) + (+1)(+1) + (+1)(-1) = 0$。解码时其他用户的贡献自动归零。

---

### ALOHA协议(重要度:★★★★★)

#### 纯 ALOHA

**纯 ALOHA**：任何站有数据就发，不等不查。发完等待确认，超时未收到确认则认为发生冲突，随机等待一段时间后重发。

#### 时隙 ALOHA

**时隙 ALOHA** 把时间划分为等长的时隙（每时隙 $= T$，即一帧的传输时间），各站只能在时隙的起始点发送。冲突窗口从 $2T$ 缩小为 $T$：只有两个站在同一时隙发出才会冲突。

![示意图](../../assets/computer-network/kb-aloha-slotted-4.svg)

时隙 ALOHA 的冲突窗口只有 $T$：帧 A 在某个时隙发出后，只有同一时隙内的其他帧才会与它冲突。前一隙的帧在 A 开始前已结束，后一隙的帧在 A 结束后才开始，都不会干扰 A。

---

### CSMA协议(重要度:★★★★★)

#### 1-坚持 CSMA

**1-坚持 CSMA**（1-persistent CSMA）：发送前先监听。

1. 信道空闲：立即发送。
2. 信道忙：持续监听，一旦空闲立即发送。

多个站同时等待信道时，空闲瞬间会同时发出，必然冲突。1-坚持最激进，适合轻负载。

#### 非坚持 CSMA

**非坚持 CSMA**（Non-persistent CSMA）：发送前先监听。

1. 信道空闲：立即发送。
2. 信道忙：随机等待一段时间后再重新监听。

多个等待站因等待时间不同而错开，冲突概率降低，但可能浪费空闲时间。非坚持适合重负载。

#### p-坚持 CSMA

**p-坚持 CSMA**（p-persistent CSMA）适用于**时隙信道**。发送前先监听：

1. 信道忙：持续监听直到空闲。
2. 信道空闲：以概率 $p$ 在本时隙发送，以概率 $1-p$ 推迟到下一时隙再做决定。

$p$ 太大接近 1-坚持，$p$ 太小信道空转，p-坚持是前两者的折中。

#### 三种 CSMA 比较

<!-- html 块无法表达,降级代码块 -->

```
<table style="width:100%;border-collapse:collapse;font-size:13px;font-family:system-ui,sans-serif;margin:0;"><thead><tr style="background:#f1f5f9;"><th style="padding:6px 10px;text-align:left;border:1px solid #e2e8f0;">策略</th><th style="padding:6px 10px;text-align:center;border:1px solid #e2e8f0;">信道忙时的行为</th><th style="padding:6px 10px;text-align:center;border:1px solid #e2e8f0;">信道闲时的行为</th><th style="padding:6px 10px;text-align:center;border:1px solid #e2e8f0;">冲突风险</th><th style="padding:6px 10px;text-align:center;border:1px solid #e2e8f0;">适用场景</th></tr></thead><tbody><tr><td style="padding:5px 10px;border:1px solid #e2e8f0;font-weight:700;">1-坚持</td><td style="padding:5px 10px;text-align:center;border:1px solid #e2e8f0;">持续监听，一旦空闲立即发</td><td style="padding:5px 10px;text-align:center;border:1px solid #e2e8f0;">立即发（概率 1）</td><td style="padding:5px 10px;text-align:center;border:1px solid #e2e8f0;">高（多站同时扑上）</td><td style="padding:5px 10px;text-align:center;border:1px solid #e2e8f0;">轻负载</td></tr><tr style="background:#f8fafc;"><td style="padding:5px 10px;border:1px solid #e2e8f0;font-weight:700;">非坚持</td><td style="padding:5px 10px;text-align:center;border:1px solid #e2e8f0;">不等了，随机等一段再听</td><td style="padding:5px 10px;text-align:center;border:1px solid #e2e8f0;">立即发</td><td style="padding:5px 10px;text-align:center;border:1px solid #e2e8f0;">低（等待时间不同，错开）</td><td style="padding:5px 10px;text-align:center;border:1px solid #e2e8f0;">重负载</td></tr><tr><td style="padding:5px 10px;border:1px solid #e2e8f0;font-weight:700;">p-坚持</td><td style="padding:5px 10px;text-align:center;border:1px solid #e2e8f0;">持续监听直到空闲</td><td style="padding:5px 10px;text-align:center;border:1px solid #e2e8f0;">以 p 概率发，1−p 推迟</td><td style="padding:5px 10px;text-align:center;border:1px solid #e2e8f0;">中（p 控制）</td><td style="padding:5px 10px;text-align:center;border:1px solid #e2e8f0;">时隙信道，中等负载</td></tr></tbody></table>
```

---

### CSMA/CD协议(重要度:★★★★★)

#### 先听后发，边发边听

**CSMA/CD**（载波监听多点接入 / 碰撞检测）的做法：

1. **发前先听**：信道空闲才发送。
2. **发中再听**：边发送边检测是否有其他站也在发送。

一旦检测到冲突，立即停止。

载波监听不能消灭冲突。电磁波在总线上的传播需要时间，两个站可能同时监听到空闲并开始发送，都发出去了才发现撞了。CSMA/CD 的贡献是检测冲突并迅速止损。

设总线上相距最远的两个站之间的**单程传播时延**为 $\tau$。

最坏情况：A 发送后经过接近 $\tau$ 的时间，信号才到达 B；而 B 在此之前监听到空闲，也发出了帧。B 的帧与 A 的帧碰撞，碰撞信号再经过 $\tau$ 时间传回 A，A 从发出到检测到冲突最长需要 $2\tau$。

#### 争用期与最短帧长

争用期（冲突窗口）$= 2\tau$。一个站发出帧后，最多经过 $2\tau$ 时间就能知道是否发生了冲突。如果 $2\tau$ 内没有检测到冲突，说明信道已被本站抢占成功，后续不会再有冲突。

帧的传输时间必须 $\geq$ 争用期。如果帧太短，发送方在 $2\tau$ 之前就已经发完，碰撞信号传回来时本站早已停止，这次冲突不会被发现，帧丢失了发送方也不知道。

```anim:kb-csma-contention-anim
CSMA/CD 最坏情况碰撞检测动画
```

$$
\text{最短帧长} = 2\tau \times \text{数据率}
$$

**例** 10 Mbps 以太网，$2\tau = 51.2\ \mu\text{s}$（最大电缆长度 2.5 km、4 个中继器下的最坏往返时延），最短帧长 $= 51.2\ \mu\text{s} \times 10\ \text{Mbps} = 512\ \text{bit} = 64\ \text{字节}$。

接收方收到任何短于 64 字节的帧，一律当作**冲突碎片**丢弃。如果上层数据不足 64 字节，MAC 层会自动填充到 64 字节。最短帧长 $= 2\tau \times$ 数据率，因此数据率越高，最短帧长越大，或 $2\tau$ 必须相应缩小（如千兆以太网将 $2\tau$ 缩至 $0.512\ \mu\text{s}$）。

#### 冲突停发，随机重发

检测到冲突后，站点立即停止发送，并发出一个**强化碰撞信号**（jam signal，32 或 48 比特的人为干扰），确保总线上所有站都知道发生了冲突。然后进入退避流程。

退避算法采用**截断二进制指数退避**（Truncated Binary Exponential Backoff）：

1. **基本退避时间**取 $2\tau$（争用期），称为一个**时隙**（slot time）。

2. 设已冲突 $k$ 次（$k = 1, 2, 3, \ldots$），从集合 $\{0, 1, 2, \ldots, 2^{\min(k,\ 10)} - 1\}$ 中随机选一个整数 $r$。

3. 等待时间 $= r \times 2\tau$（退避 $r$ 个时隙）。

4. 重传后若再冲突，$k$ 加 1，重复步骤 2–3。

5. 冲突达到 16 次仍未成功，丢弃该帧，向高层报告错误。

"截断"指 $k$ 超过 10 后指数不再增长，$r$ 的取值范围锁定在 $\{0, \ldots, 1023\}$。第 11–16 次冲突的退避窗口和第 10 次相同。

退避窗口随冲突次数指数增长，越堵等得越分散，降低再次冲突的概率。两台主机第一次冲突后，各从 $\{0, 1\}$ 中随机选 $r$，避开的概率为 50%。

<!-- html 块无法表达,降级代码块 -->

```
<table style="width:100%;border-collapse:collapse;font-size:13px;font-family:system-ui,sans-serif;margin:0;"><thead><tr style="background:#f1f5f9;"><th style="padding:6px 8px;text-align:center;border:1px solid #e2e8f0;">冲突次数 k</th><th style="padding:6px 8px;text-align:center;border:1px solid #e2e8f0;">r 的取值范围</th><th style="padding:6px 8px;text-align:center;border:1px solid #e2e8f0;">最大退避时隙数</th><th style="padding:6px 8px;text-align:center;border:1px solid #e2e8f0;">最大等待时间（10Mbps）</th></tr></thead><tbody><tr><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">1</td><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">{0, 1}</td><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">1</td><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">51.2 μs</td></tr><tr style="background:#f8fafc;"><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">2</td><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">{0, 1, 2, 3}</td><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">3</td><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">153.6 μs</td></tr><tr><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">3</td><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">{0, …, 7}</td><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">7</td><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">358.4 μs</td></tr><tr style="background:#f8fafc;"><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">…</td><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">…</td><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">…</td><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">…</td></tr><tr><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">10</td><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">{0, …, 1023}</td><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">1023</td><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">≈ 52.4 ms</td></tr><tr style="background:#f8fafc;"><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">11–16</td><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">{0, …, 1023}</td><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">1023</td><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">≈ 52.4 ms（截断）</td></tr><tr><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;">≥ 16</td><td style="padding:5px 8px;text-align:center;border:1px solid #e2e8f0;" colspan="3">丢弃帧，向上层报告错误</td></tr></tbody></table>
```

---

### CSMA/CA协议(重要度:★★★★★)

#### CSMA/CA 的思路

**CSMA/CA** 采用**冲突避免**而非冲突检测。无线局域网中，发送方在发送时信号最强，无法同时检测到远端的冲突信号，即无法做到"边发边听"。因此无线网络在发送前和发送中都采取一系列措施降低冲突概率。

**CSMA/CD** 用于有线以太网，可以检测冲突。

**CSMA/CA** 用于无线局域网（802.11 WiFi）。

两者都在发送前监听，但 CA 还多了确认、预留信道和退避等机制。

#### RTS/CTS 握手全流程

![示意图](../../assets/computer-network/kb-csma-ca-proc-1.svg)

上图完整展示了 RTS/CTS 握手的时延过程：

① 源站监听 DIFS 空闲后发送 **RTS 帧**，RTS 只发给目的站。
② 目的站收到 RTS，等待 SIFS 后回复 **CTS 帧**，CTS 同时广播到源站和其他站点。其他站点通过 CTS 的 NAV 字段获知信道被占用。
③ 源站收到 CTS，等待 SIFS 后发送 **DATA 数据帧**。
④ 目的站收到 DATA，等待 SIFS 后回复 **ACK 确认帧**，ACK 同样广播到其他站点。

#### 二进制指数退避

发生冲突后，发送方需要等待一段随机时间再重试。退避计数器在区间 $[0, CW]$ 中随机选取一个值，$CW$（竞争窗口）随冲突次数 $k$ 按指数增长：$CW = 2^k \times W_{min}$。

**初始值**：$CW$ 初始为 $W_{min}$（通常 15 个时隙，每个时隙约 9 μs），即退避区间 $[0, 15]$。

**增长规则**：每发生一次冲突，$CW$ 翻倍。第 1 次冲突 $CW=31$，第 2 次 $CW=63$，第 3 次 $CW=127$……以此类推，每次翻倍指数增长。

**上限**：$CW$ 最多涨到 $W_{max}$（通常 1023），之后不再翻倍，但退避计数器仍可继续取 $[0, 1023]$ 中的随机值。成功传输后 $CW$ 重置为 $W_{min}$。

**例** 假设时隙 9 μs，第 1 次冲突从 $[0, 15]$ 中随机选 6，等待 $6 \times 9 = 54$ μs；第 2 次冲突 $CW$ 翻倍为 31，从 $[0, 31]$ 中随机选 20，等待 $20 \times 9 = 180$ μs；第 3 次冲突 $CW=63$，以此类推。冲突越多，等待时间越长，指数增长使冲突概率快速下降。

#### NAV 网络分配向量

**NAV**（Network Allocation Vector）是 RTS/CTS 帧中携带的一个计时字段，告诉周围所有站点信道已被预约一段时间，期间不要发送。其他站点听到 RTS 或 CTS 后，把帧中携带的 NAV 值设为倒计时，归零前保持沉默。

比如：站点 A 向 B 发 RTS，NAV 字段设为 500 μs（足以覆盖后续 CTS+DATA+ACK）。B 回复 CTS，NAV 同样为 500 μs。周围站点 C 只听到 RTS，站点 D 只听到 CTS，两者都会将自己的 NAV 设为 500 μs，在 500 μs 内保持静默。500 μs 后 NAV 归零，信道重新竞争。
